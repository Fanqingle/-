统计大写字母个数

题目描述
    找出给定字符串中大写字符(即'A'-'Z')的个数
    接口说明
        原型：int calcCapital(String str);
        返回值：int

输入描述:
    输入一个String数据

输出描述:
    输出string中大写字母的个数

输入例子:
    add123#$%#%#O

输出例子:
    1