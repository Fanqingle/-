统计每个月兔子的总数
参与人数：4时间限制：1秒空间限制：32768K
通过比例：42.86%
最佳记录：0 ms|8460K （来自  i_square）
 算法知识视频讲解
题目描述

有一对兔子，从出生后第3个月起每个月都生一对兔子，小兔子长到第三个月后每个月又生一对兔子，
假如兔子都不死，问每个月的兔子总数为多少？
/**      * 统计出兔子总数。      *       * @param monthCount 第几个月      *
@return 兔子总数      */     public static int getTotalCount(int monthCount)
 {         return 0;     }
输入描述:

输入int型表示month


输出描述:

输出兔子总数int型

输入例子:

9

输出例子:

34