查找两个字符串a,b中的最长公共子串

题目描述
    查找两个字符串a,b中的最长公共子串

输入描述:
    输入两个字符串

输出描述:
    返回重复出现的字符

输入例子:
    abcdefghijklmnop
    abcsafjklmnopqrstuvw

输出例子:
    jklmnop